def main():
    name = input("What is your name? ")
    age = int(input("How old are you? "))
    hundredYear = (2019 - age) + 100
    print(name, "will be 100 years old in the year", hundredYear)

main()